export const loginActionTypes = {

}

export const globalActionTypes = {
  SHOW_LOADER: 'SHOW_LOADER',
  HIDE_LOADER: 'HIDE_LOADER',
  UPDATE_SELECTED_PAGE: "UPDATE_SELECTED_PAGE",
  UPDATE_USER_DATA: "UPDATE_USER_DATA"
};