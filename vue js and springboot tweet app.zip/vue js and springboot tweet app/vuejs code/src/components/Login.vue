<template>
  <div class="container">
    <form>
      <div class="well">
        <h4>Login</h4>
        <h5 v-if="isEditting==true" style="color:red;">{{message}}</h5>
        <div class="form-group">
          <label class="pull-left"> Login ID </label>

          <input
            type="text"
            class="form-control"
            placeholder="Login ID"
            v-model="User.username"
          />
        </div>

        <div class="form-group">
          <label class="pull-left"> Password </label>

          <input
            type="Password"
            class="form-control"
            placeholder="Password"
            v-model="User.password"
          />
        </div>
      </div>

      <button
        class="btn btn-large btn-block btn-success full-width"
       v-on:click.prevent="addToAPI"
      >
        Login
      </button>
      <br>
      <div>
        <div style="display:inline-block;" align="left">
       <!-- <router-link to="/Register">

        <button

          type="submit"

          class="btn btn-large  btn-primary full-width"
          
         >

          Forgot Password

        </button>

      </router-link> -->
      </div>
      <div style="display:inline-block;margin-left: 755px;" align="right">
      Not have a account? Click 
       <router-link to="/Register">

        <button

          type="submit"

          class="btn btn-large  btn-primary full-width"

         >

          Register

        </button>

      </router-link>
      </div>
      </div>
    </form>
  </div>
</template>



<script>
/*eslint-disable */

// import axios from "axios";

//import router from '../main';

export default {
  data() {
    return {
    message:'',
    isEditting:false,
      User: {
        username: "",
        password: ""
      }
    }
  },
//   mounted: function(){
//       this.
//   },
  methods: {
    addToAPI() {
      console.log(this.User);
        this.$http.get("http://localhost:8060/api/v1.0/tweets/login")
        .then((response) => {
          console.log("data:",response);
          var arr=response.data;
          var flag=false;
          arr.forEach((res,index)=>{
            if(res.loginId==this.User.username && res.password==this.User.password){
                flag=true;
            }
          });
             if(flag){
                this.$router.push({
                    path: "/AccountDetails/"+this.User.username,
                    params:{username:this.User.username}
                }); 
             }
             else{
               
                 this.isEditting=true
                 this.message = "Username/password is wrong...!"
             }
        //   this.$router.push({
        //     path: "/AccountDetails",
        //   });
        })

        .catch((error) => { 
            this.isEditting=true
            this.message="Username/password is wrong...!"
          console.log(error.response);
        });
    },
  },
};
</script>

<style scoped>
h1,
h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;

  padding: 0;
}

li {
  display: inline-block;

  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>