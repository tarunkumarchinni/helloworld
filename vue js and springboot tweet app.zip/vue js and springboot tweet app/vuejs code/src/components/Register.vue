<template>
  <div class="container">
    <form @submit.prevent="handleSubmit">
      <div class="well">
        <h4>Registration</h4>
          <p v-if="isEditing==true" style="color:red;">{{message}}</p>
        <div class="form-group">
          <label class="pull-left"> First Name </label>

          <input
            type="text"
            class="form-control"
            placeholder="First Name"
            v-model="User.firstName"
            :class="{ 'is-invalid': submitted && $v.User.firstName.$error }"
          />

          <div
            v-if="submitted && !$v.User.firstName.required" style="color:red;"
            class="invalid-feedback" 
          >
            First Name is required
          </div>
        </div>
        <div class="form-group">
          <label class="pull-left"> Last Name </label>

          <input
            type="text"
            class="form-control"
            placeholder="Last Name"
            v-model="User.lastName"
            :class="{ 'is-invalid': submitted && $v.User.lastName.$error }"
          />

          <div
            v-if="submitted && !$v.User.lastName.required" style="color:red;"
            class="invalid-feedback" 
          >
            Last Name is required
          </div>
        </div>

        <div class="form-group">
          <label class="pull-left"> Email </label>

          <input
            type="email"
            class="form-control"
            placeholder="Email "
            v-model="User.email"
            :class="{ 'is-invalid': submitted && $v.User.email.$error }"
          />

          <div
            v-if="submitted && !$v.User.email.required"
            class="invalid-feedback" style="color:red;"
          >
            email is required
          </div>
          <!-- <div
            v-if="submitted && !$v.User.validationEmailandLiginID.validateemail"
            class="invalid-feedback" style="color:red;"
          >
            Email and Login ID should not be equal.
          </div> -->
        </div>


        <div class="form-group">
          <label class="pull-left"> Login ID </label>

          <input
            type="text"
            class="form-control"
            placeholder="Login ID"
            v-model="User.username"
            :class="{ 'is-invalid': submitted && $v.User.username.$error }"
          />

          <div
            v-if="submitted && !$v.User.username.required"
            class="invalid-feedback" style="color:red;"
          >
            username is required
          </div>
          <div
            v-if="submitted && this.flag"
            class="invalid-feedback" style="color:red;"
          >
            username is already exists please provide another one.
          </div>
          <div
            v-if="submitted && !$v.User.validationEmailandLiginID.validatelogin"
            class="invalid-feedback" style="color:red;"
          >
            Email and Login ID should not be equal.
          </div>
        </div>

        <div class="form-group">
          <label class="pull-left"> Password </label>

          <input
            type="password"
            class="form-control"
            placeholder="Password "
            v-model="User.password"
            :class="{ 'is-invalid': submitted && $v.User.password.$error }"
          />

          <div
            v-if="submitted && !$v.User.password.required"
            class="invalid-feedback" style="color:red;"
          >
            Password is required
          </div>
        </div>

        <div class="form-group">
          <label class="pull-left"> Confirm Password </label>

          <input
            type="password"
            class="form-control"
            placeholder="Confirm Password "
            v-model="User.confirmPassword"
            :class="{ 'is-invalid': submitted && $v.User.confirmPassword.$error }"
          />

          <div
            v-if="submitted && !$v.User.confirmPassword.required"
            class="invalid-feedback" style="color:red;"
          >
            Confirm Password is required
          </div>
          <div
            v-if="submitted && !$v.User.validatePassword.confirmPasswordData"
            class="invalid-feedback" style="color:red;"
          >
            Entered Password and Confirm Password are not matching.
          </div>
        </div>

        <div class="form-group">
          <label class="pull-left"> Contact </label>

          <input
            type="number"
            class="form-control"
            placeholder="Contact "
            v-model="User.contact"
            :class="{ 'is-invalid': submitted && $v.User.contact.$error }"
          />

          <div
            v-if="submitted && !$v.User.contact.required"
            class="invalid-feedback" style="color:red;"
          >
            Contact is required
          </div>
        </div>

      </div>

      <button
        type="submit"
        class="btn btn-large btn-block btn-success full-width"
      >
        Submit
      </button>
      <br>
        Want to cancel? Click 
      <router-link to="/">
        <button class="btn btn-large  btn-danger full-width">
          Cancel
        </button>
      </router-link>
      <br><br><br><br><br>
    </form>
  </div>
</template>



<script>
// import router from "vue-router";

import axios from "axios";

import { required } from "vuelidate/lib/validators";

export default {
  data() {
    return {
      flag:false,
      message:'',
      isEditing:false,
      User: {
        firstName: "",
        lastName: "",
        email:"",
        username: "",

        password: "",
        confirmPassword:"",

        contact: "",
      },

      submitted: false,
    };
  },

  validations: {
    User: {
      firstName: { required },
      lastName: { required },
      email:{ required },
      username: { required },

      password: { required },
      confirmPassword:{ required },

      contact: { required },
      validatePassword:{
        confirmPasswordData(){
          if(this.User.confirmPassword == this.User.password){
            return true;
          }
          else{
            return false;
          }
        }
      },
      validationEmailandLiginID:{
        validatelogin(){
          if(this.User.loginId != this.User.email){
            return true;
          }
          else{
            return false;
          }
        }
      }
      // validateLoginId:{
      //   loginIdData() {
          
      //     console.log(this.User.username);
      //     this.$http.get("http://localhost:8060/api/v1.0/tweets/login")
      //     .then((response) => {
      //       console.log("data:",response);
      //       var arr=response.data;
            
      //       arr.forEach((res)=>{
      //         console.log("result each",res.loginId,this.User.username)
      //         if(res.loginId==this.User.username){
      //           console.log("inside")
      //             this.flag=true;
                  
      //         }
      //       });    
      //     })
      //     console.log(this.flag)
      //     return this.flag;
      //   },
      // },
    },
  },

  methods: {
    handleSubmit() {
      this.submitted = true;

      // stop here if form is invalid

      this.$v.$touch();

      if (this.$v.$invalid) {
        return;
      }

      let newUser = {
        
        firstName: this.User.firstName,

        lastName: this.User.lastName,

        email: this.User.email,

        loginId: this.User.username,

        password: this.User.password,

        confirmPassword: this.User.confirmPassword,

        contactNumber: this.User.contact,

      };

      console.log(newUser);

      // const isvalid = this.validations;

      // if (isvalid) {

      axios

        .post("http://localhost:8060/api/v1.0/tweets/register", newUser)

        .then((response) => {
          console.log(response);
          // router.push({ name: 'Login' })
          console.log("registered data",response)
          if(response.data.output){
                  this.isEditing=true
                  this.message="Username already exists,So please provide another..."
                  console.log("User already exists...!");
          }
          else{
              this.$router.push({
                path: "/login",
              })
          }
        })
         .catch((error) => {
              console.log(error.response.data);
              
            });
    },

    // },
  },
};
</script>



<!-- Add "scoped" attribute to limit CSS to this component only -->

<style scoped>
h1,
h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;

  padding: 0;
}

li {
  display: inline-block;

  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>