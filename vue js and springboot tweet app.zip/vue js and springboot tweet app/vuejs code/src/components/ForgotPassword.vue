<template>
  <div class="container">
    <form>
      <div class="well">
        <h4></h4>
        <h5 v-if="isEditting==true" style="color:red;">{{message}}</h5>
        <div class="form-group">
          <label class="pull-left"> Login ID </label>

          <input
            type="text"
            class="form-control"
            placeholder="Login ID"
            v-model="User.username"
            :class="{ 'is-invalid': submitted && $v.User.username.$error }"
          disabled>
          <div
            v-if="submitted && !$v.User.username.required"
            class="invalid-feedback" style="color:red;"
          >
            username is required
          </div>
          <div
            v-if="submitted && this.flag"
            class="invalid-feedback" style="color:red;"
          >
            username is already exists please provide another one.
          </div>
        </div>

        <div class="form-group">
          <label class="pull-left"> New Password </label>

          <input
            type="password"
            class="form-control"
            placeholder="Password "
            v-model="User.password"
            :class="{ 'is-invalid': submitted && $v.User.password.$error }"
          />

          <div
            v-if="submitted && !$v.User.password.required"
            class="invalid-feedback" style="color:red;"
          >
            Password is required
          </div>
        </div>

        <div class="form-group">
          <label class="pull-left"> Confirm Password </label>

          <input
            type="password"
            class="form-control"
            placeholder="Confirm Password "
            v-model="User.confirmPassword"
            :class="{ 'is-invalid': submitted && $v.User.confirmPassword.$error }"
          />

          <div
            v-if="submitted && !$v.User.confirmPassword.required"
            class="invalid-feedback" style="color:red;"
          >
            Confirm Password is required
          </div>
          <div
            v-if="submitted && !$v.User.validatePassword.confirmPasswordData"
            class="invalid-feedback" style="color:red;"
          >
            Entered Password and Confirm Password are not matching.
          </div>
        </div>
      </div>

      <button
        class="btn btn-large btn-block btn-success full-width"
       v-on:click.prevent="addToAPI"
      >
        Reset
      </button>
      <br>
    </form>
  </div>
</template>



<script>
/*eslint-disable */

import axios from "axios";
import { required } from "vuelidate/lib/validators";
//import router from '../main';

export default {
  data() {
    return {
    message:'',
    isEditting:false,
    User: {
        idobject:"",
        firstName: "",
        lastName: "",
        email:"",
        username: this.$route.params.username,

        password: "",
        confirmPassword:"",

        contact: ""
      }
    }
  },
//   mounted: function(){
//       this.
//   },
    validations: {
    User: {
      firstName: {  },
      lastName: {  },
      email:{  },
      username: { required },
      password: { required },
      confirmPassword:{ required },

      contact: {  },
      validatePassword:{
        confirmPasswordData(){
          if(this.User.confirmPassword == this.User.password){
            return true;
          }
          else{
            return false;
          }
        }
      },

    },
  },
  methods: {
    addToAPI() {
        this.submitted = true;

      // stop here if form is invalid

      this.$v.$touch();

      if (this.$v.$invalid) {
        return;
      }
      console.log(this.User);
      let newUser = {
        id:this.User.idobject,
        firstName: this.User.firstName,

        lastName: this.User.lastName,

        email: this.User.email,

        loginId: this.User.username,

        password: this.User.password,

        confirmPassword: this.User.confirmPassword,

        contactNumber: this.User.contact,

      };

    console.log("data  ",newUser)
        axios.put("http://localhost:8060/api/v1.0/tweets/"+this.User.username+"/forgot",newUser)
        .then((response) => {
          console.log("data:",response);
          this.$router.push({
                path: "/login",
              })
        
        })

        .catch((error) => { 
            this.isEditting=true
            this.message="Username/password is wrong...!"
          console.log(error.response);
        });
    },
  },
};
</script>

<style scoped>
h1,
h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;

  padding: 0;
}

li {
  display: inline-block;

  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>