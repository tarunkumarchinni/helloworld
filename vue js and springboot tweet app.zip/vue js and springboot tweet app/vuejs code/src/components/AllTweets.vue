<template>
  <div class="container">
    <router-link to="/login">
      <button class="btn btn-large full-width" style="float: right">
        logout
      </button>
    </router-link>
    &nbsp;&nbsp;
    <h4>{{ this.message }}</h4>
<button
      class="btn btn-large btn-success full-width"
      style="float: right"
      @click="gotoAllTweets(userid)"
    >
      Show My Tweets
    </button>
    <hr />
    <div
      v-for="tweet in accounts"
      v-bind:key="tweet.id"
      style="margin-bottom: 30px; width: 500px;" class="center"
    >
      <div style="background: #f2f2f2;">
        <b-card
          no-body
          class="overflow-hidden"
          style="max-width: 540px; height: 100px"
        >
          <b-row no-gutters>
            <b-col md="3">
              <b-card-img
                src="https://picsum.photos/400/400/?image=20"
                alt="Image"
                width="80px"
                style="margin-top: 10px"
                class="rounded-0"
              ></b-card-img>
            </b-col>
            <b-col md="6">
              <b-card-body>
                <div style="display: inline-flex">
                  <b-card-title style="margin-right: 30px">{{
                    tweet.loginId
                  }}</b-card-title>
                  <b-card-title style="width: 250px;">{{ tweet.timestamp }}</b-card-title>
                </div>
                <b-card-text>
                  {{ tweet.tweet }}
                </b-card-text>
              </b-card-body>
            </b-col>
          </b-row>
        </b-card>
        <!-- reply  list-->
        <div v-if="tweet.id==displayReply">
          <div
      v-for="replytweet in tweet.reply"
      v-bind:key="replytweet.id"
      style="margin-bottom: 30px; width: 500px;" class="center"
    >
      <div style="background: #f2f2f2;">
        <b-card
          no-body
          class="overflow-hidden"
          style="max-width: 540px; height: 100px"
        >
          <b-row no-gutters>
            <b-col md="3">
              <b-card-img
                src="https://picsum.photos/400/400/?image=20"
                alt="Image"
                width="80px"
                style="margin-top: 10px"
                class="rounded-0"
              ></b-card-img>
            </b-col>
            <b-col md="6">
              <b-card-body>
                <div style="display: inline-flex">
                  <b-card-title style="margin-right: 30px">{{
                    replytweet.loginId
                  }}</b-card-title>
                  <b-card-title style="width: 250px;">{{ replytweet.timestamp }}</b-card-title>
                </div>
                <b-card-text>
                  {{ replytweet.tweet }}
                </b-card-text>
              </b-card-body>
            </b-col>
          </b-row>
        </b-card>
         </div>
        </div>
        </div>
        <!-- insert post -->
    <div v-if="tweet.id==replyStatus"
      style="margin-bottom: 30px;width: 500px;" class="center"
    >
      <div style="background: #f2f2f2;height: 180px;">
        <b-card
          no-body
          class="overflow-hidden"
          style="max-width: 540px; height: 100px;display:flex;"
        >
          <b-row no-gutters>
            <b-col md="3">
              <b-card-img
                src="https://picsum.photos/400/400/?image=20"
                alt="Image"
                width="80px"
                style="margin-top: 40px"
                class="rounded-0"
              ></b-card-img>
            </b-col>
            <b-col md="6">
              <b-card-body>
                <form @submit.prevent="handleSubmit(tweet.id)">
                <div style="display: inline-flex">
                  <b-card-title style="margin-right: 30px">
                    {{userid}}
                  </b-card-title>
                  <b-card-title style="width: 250px;">{{dateTimestamp}} </b-card-title>
                </div>
                
                  
                  <div class="form-group">
                      <textarea class="form-control"  v-model="userPost.tweet" maxlength="144" style="width:350px;height:80px;" :class="{ 'is-invalid': submitted && $v.userPost.tweet.$error }"></textarea>
                      <div
            v-if="submitted && !$v.userPost.tweet.maxLength"
            class="invalid-feedback" style="color:red;"
          >
            Tweet must be in 144 characters
          </div>
                  </div>
                    <button class="btn btn-block btn-success" type="submit" style="width:100px;margin-left:250px;">Post</button>
                  
                </form>
              </b-card-body>
            </b-col>
          </b-row>
        </b-card>
      </div>
    </div>
    <!-- end insert -->

        <button
        class="btn btn-large  btn-primary full-width"
        @click="likecount(tweet.loginId,tweet.id)"
      >
        likes {{tweet.like}}
      </button>
      <button
        class="btn btn-large  btn-primary full-width"
        @click="commentTweet(tweet.id)"
      >
        Comments
      </button>
        <button
        class="btn btn-large  btn-primary full-width"
        @click="replyTweet(tweet.id)"
      >
        Reply
      </button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import { maxLength } from "vuelidate/lib/validators";

export default {
  data: function () {
    return {
      message: "Posted Tweets details",

      userid: this.$route.params.username,

      isEditing: false,
      replyStatus:"",
      accounts: Array,
      displayReply:"",
      userPost:{
        tweet:""
      },
      submitted: false,
      timestamp:"",
      dateTimestamp:""
    };
  },
  validations: {
    userPost: {
      tweet: { maxLength:maxLength(144) }
    },
  },
  mounted: function () {
    console.log("inmounted starat");
    this.getAccounts();
  },
  created() {
    setInterval(this.getNow, 1000);
  },

  methods: {
    gotoAllTweets: function(id){
        console.log(id);

      console.log(this.$router);

      this.$router.push({
        path: "/AccountDetails/" + id,

        params: { username: id },
      });
    },
    getNow: function() {
                    const today = new Date();
                     const date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
                    const time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
                     const dateTime = date +' '+ time;
                    this.timestamp = time;
                    this.dateTimestamp=dateTime;
    },
    replyTweet: function(id){
        this.replyStatus=id;
       console.log("reply",id)
    },
    commentTweet: function (id){
        this.displayReply=id;
        console.log("id",id);
    },
    likecount: function (username,id) {
      console.log(id);

      console.log(this.$router);
      
      axios

        .put("http://localhost:8060/api/v1.0/tweets/"+username+"/like/"+id)

        .then((response) => {
          console.log(response);
          // router.push({ name: 'Login' })
          console.log("registered data",response)
          
              this.$router.go(this.$router.currentRoute)
          
        })
         .catch((error) => {
              console.log(error.response.data);
              
            });
    },
    
    handleSubmit: function(id) {
      this.submitted = true;

      // stop here if form is invalid

      this.$v.$touch();

      if (this.$v.$invalid) {
        return;
      }

      let newPost = {
        loginId: this.userid,
        tweet: this.userPost.tweet,
        timestamp:this.dateTimestamp,
        like:0,
        reply:[],
      };

      console.log("entered post",newPost);
      axios

        .post("http://localhost:8060/api/v1.0/tweets/"+this.userid+"/reply/"+id, newPost)

        .then((response) => {
          console.log(response);
          // router.push({ name: 'Login' })
          console.log("registered data",response)
          
              this.$router.go(this.$router.currentRoute)
          
        })
         .catch((error) => {
              console.log(error.response.data);
              
            });
    },
    getAccounts: function () {
      axios
        .get("http://localhost:8060/api/v1.0/tweets/all")

        .then((response) => {
          this.accounts = response.data;

          console.log(response);

          console.log(this.accounts);

          console.log(status);
        })

        .catch((error) => {
          if (error.response.status == 404) {
            this.accounts = error.response.data;
          }

          console.log(this.accounts.length);

          console.log(this.accounts);
        });
    },
  },
};
</script>

<style scoped>
tr:nth-child(even) {
  background-color: #f2f2f2;
}
.center {
margin: auto;
width: 10%;
border: 1px solid #00aeff;
padding: 1px;
}
</style>