package com.tweetapp.repository;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.entity.UserRegistration;
//@Repository
@EnableScan
public interface UserRegistrationRepository extends CrudRepository<UserRegistration, String>{
 public UserRegistration findByLoginId(String username);
 public UserRegistration findByLoginIdAndEmail(String username,String email);
 public UserRegistration findByEmail(String email);
 public boolean existsByLoginIdAndPassword(String loginId, String password);
 public boolean existsByLoginId(String loginId);
 
}
