package com.tweetapp.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.tweetapp.entity.UserRegistration;
import com.tweetapp.repository.UserRegistrationRepository;


@Service
public class RegistrationService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	UserRegistrationRepository userRegistrationRepository;
	
	public Boolean saveUserRegistration(UserRegistration registration) throws Exception {
		logger.info("Save user method - REGISTER");
		UserRegistration iduser=userRegistrationRepository.findByLoginId(registration.loginId);
		UserRegistration emailuser=userRegistrationRepository.findByEmail(registration.email);
		boolean existingUser=iduser==null?true:false;
		if(existingUser) existingUser=emailuser==null?true:false;
		logger.info("Checking UserAlready Exist"+existingUser);
		if(!existingUser) {
			return false; 
			//logger.info(new Exception("User already Exist!");
		} else userRegistrationRepository.save(registration);
	 return true;
	}
	public UserRegistration getUser(String username) {
		logger.info("Enter into get user method");
		UserRegistration userreg = userRegistrationRepository.findByLoginId(username);
		boolean data=userreg==null?false:true;
		if(data) userreg.password = null;
		return userreg;
	}
	public List<UserRegistration> getAllUser(){
		logger.info("Enter into get user method");
		return (List<UserRegistration>) userRegistrationRepository.findAll();
	}
	public Boolean updatePassword(String loginId,String oldPassword,String newPassword) throws Exception {
		logger.info("Enter into update password method");
		boolean valid=userRegistrationRepository.existsByLoginIdAndPassword(loginId,oldPassword);
		if(valid) {
			UserRegistration user=userRegistrationRepository.findByLoginId(loginId);
			user.setPassword(newPassword);
			userRegistrationRepository.save(user);
		} else {
			return false;
			//throw new Exception("Old password incorrect");
		}
		return true;
	}
	public String forgetPassword(String loginId,String newPassword) throws Exception {
		logger.info("Enter into forget password method");
		boolean valid=userRegistrationRepository.existsByLoginId(loginId);
		if(valid) {
			UserRegistration user=userRegistrationRepository.findByLoginId(loginId);
			user.setPassword(newPassword);
			userRegistrationRepository.save(user);
			return "Password updated successfully";
		}
		else {
			logger.info("Incorrect loginId");
			return "Invalid credentials";
		}
	}
	public Boolean validCredentials(String loginId, String password) {
		return userRegistrationRepository.existsByLoginIdAndPassword(loginId, password);
	}
}
