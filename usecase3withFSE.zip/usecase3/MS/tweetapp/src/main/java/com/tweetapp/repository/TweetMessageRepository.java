package com.tweetapp.repository;

import java.util.List;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tweetapp.entity.TweetMessage;
import com.tweetapp.entity.UserRegistration;

//@Repository
@EnableScan
public interface TweetMessageRepository extends CrudRepository<TweetMessage, String>{
List<TweetMessage> findByLoginId(String username);
TweetMessage findByIdAndLoginId(String id,String LoginId);
void deleteByIdAndLoginId(String id,String LoginId);
}
