package com.tweetapp.repository;

import java.util.List;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.entity.ReplyTweetMessage;


//@Repository
@EnableScan
public interface ReplyTweetMessageRepository extends CrudRepository<ReplyTweetMessage, String> {
	List<ReplyTweetMessage> findByTweetMessageId(String tweetMessageId);
}
