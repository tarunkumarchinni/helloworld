import React, { Component } from 'react';
import './Tweet.scss';
import axios from 'axios';
import posttweet from '../data/posttweet.json'
import viewmytweet from '../data/viewmytweet.json'
import othertweet from '../data/othertweet.json'

class Tweet extends Component {
    
    constructor(props) {
        super(props);
        this.state = {
            message: '',
            notemessage: "Note: Max characters should be less than 144!",
            tweet: '',
            othercomments: '',
            like: false,
            myreplyerror: '',
            mycomments: '',
            myupdatetext: '',
            isDelete: true,
            showOptions: true,
            postOption: false,
            displayreplies: ''
        }
        this.control = {};
        switch(this.props.type){
            case "POST":
                this.control = posttweet;
                break;
            case "VIEW":
                console.log(this.props.user);
                this.control = (this.props.user === 'A') ? viewmytweet : othertweet; //viewmytweet   othertweet
                axios.get(`http://localhost:8081/tweets/replyTweet/${this.props.data.id}`).then((res)=>{
                    if(res.data.length !== 0) this.setState({displayreplies: res.data});
                    this.setState({showOptions: !this.state.showOptions, postOption: true});
                }).catch((err)=>{
                    console.log(err);
                    // this.setState({a: 'Error: Service Down'});
                });
                break;
        }
        console.log(this.control);
    }

    getPostTime = () => {
        var today = new Date();
        let hrs = today.getHours();
        let mins = today.getMinutes();
        return `${today.getDate()}/${today.getMonth()+1}/${today.getFullYear()} - ${hrs<10 ? `0${hrs}` : hrs}:${mins<10 ? `0${mins}` : mins}`;
    }

    deleterelated(status){
        if(status){
            axios.delete(`http://localhost:8081/tweets/${this.props.name}/${this.props.data.id}/delete`)
                .then((res)=>{
                    this.setState({notemessage: 'The tweet has been deleted successfully!'});
                    setTimeout(() => {
                        window.location.href = '/home';
                    }, 2000);
                }).catch((err)=>{
                    console.log(err);
                    this.setState({notemessage: 'Error: Service Down'});
                });
        } else {
            this.setState({notemessage: ''});
            this.setState({isDelete: true});
        }
    }

    onButtonEvent(property){
        console.log(property);
        let msg = '', msg1 = '';
        let errmsg = false, mutedmsg = false;
        switch(property){
            case 'submittweet':
                if(this.state.tweet === '') {
                    msg = 'Tweet message cannot be empty';
                    errmsg = true;
                } else {
                    axios.post(`http://localhost:8081/tweets/${this.props.name}/add`, {
                        "tweetMessage": this.state.tweet,
                        "tweetTime": this.getPostTime()
                    }).then((res)=>{
                        if(res.data = 'Tweet posted successfully!') {
                            msg1 = res.data;
                            msg = '';
                            setTimeout(() => {
                                window.location.href = '/home';
                            },2000);
                        } else {
                            msg = res.data;
                            msg1 = '';
                        }
                        this.setState({message: msg});
                        this.setState({notemessage: msg1});
                    }).catch((err)=>{
                        console.log(err);
                        this.setState({message: 'Error: Service Down'});
                    });
                }
                break;
            case 'othersubmit':
                if(this.state.othercomments === '' && !this.state.otherlike) {
                    msg = 'Reply comment cannot be empty (or) Like this post'
                    errmsg = true;
                } else{
                    if(this.state.othercomments !== ''){
                        axios.post(`http://localhost:8081/tweets/reply`, {
                            "replyMessage": this.state.othercomments,
                            "tweetMessageId": this.props.data.id,
                            "loginId": this.props.name
                        }).then((res)=>{
                            this.setState({notemessage: 'Response submitted successfully', message: ''});
                            axios.get(`http://localhost:8081/tweets/replyTweet/${this.props.data.id}`).then((res)=>{
                                if(res.data.length !== 0) this.setState({displayreplies: res.data});
                            }).catch((err)=>{
                                console.log(err);
                                this.setState({message: 'Error getting replies'});
                            });
                        }).catch((err)=>{
                            console.log(err);
                            this.setState({message: 'Error: Service Down'});
                        });
                    } 
                    if(this.state.otherlike){
                        axios.put(`http://localhost:8081/tweets/${this.props.data.loginId}/like/${this.props.data.id}`)
                            .then((response)=>{
                                this.setState({notemessage: 'Response submitted successfully'});
                                axios.get(`http://localhost:8081/tweets/gettweet/${this.props.data.id}`)
                                    .then((res)=>{
                                        this.props.showtweet(res.data);
                                    }).catch((err)=>{
                                        console.log(err);
                                        this.setState({message: 'Error: Failed to profile info'});
                                    });
                            }).catch((err)=>{
                                console.log(err);
                                this.setState({message: 'Error: Service Down'});
                            });
                    }
                    setTimeout(() => {
                        this.setState({notemessage: ''});
                    }, 3000);
                }
                break;
            case 'otherlike':
                msg1 = !this.state.otherlike ? 'Note: Max characters should be less than 144! | You have LIKED this tweet!' : 'Note: Max characters should be less than 144!';
                msg = '';
                this.setState({otherlike: !this.state.otherlike});
                errmsg = true;
                mutedmsg = true;
                break;
            case 'myreplysubmit':
                if(this.state.mycomments === '') this.setState({myreplyerror: 'Reply comment cannot be empty'});
                else{
                    axios.post(`http://localhost:8081/tweets/reply`, {
                            "replyMessage": this.state.mycomments,
                            "tweetMessageId": this.props.data.id,
                            "loginId": this.props.name
                        }).then((res)=>{
                            this.setState({myreplyerror: 'Reply submitted successfully'});
                            axios.get(`http://localhost:8081/tweets/replyTweet/${this.props.data.id}`).then((res)=>{
                                if(res.data.length !== 0) this.setState({displayreplies: res.data});
                            }).catch((err)=>{
                                console.log(err);
                                this.setState({myreplyerror: 'Error getting replies'});
                            });
                        }).catch((err)=>{
                            console.log(err);
                            this.setState({myreplyerror: 'Error: Service Down'});
                        });
                }            
                break;
            case 'myupdate':
                if(this.state.myupdatetext === '') this.setState({message: 'Update tweet cannot be empty'});
                else{
                    axios.put(`http://localhost:8081/tweets/${this.props.name}/${this.props.data.id}/update`,this.state.myupdatetext,
                    {headers: {"Content-Type": "text/plain"}})
                        .then((response)=>{
                            this.setState({message: '', notemessage: 'Tweet updated successfully!'});
                            axios.get(`http://localhost:8081/tweets/gettweet/${this.props.data.id}`)
                                .then((res)=>{
                                    this.props.showtweet(res.data);
                                }).catch((err)=>{
                                    console.log(err);
                                    // this.setState({message: 'Error: Failed to update profile data'});
                                });
                            // setTimeout(() => {
                            //     window.location.href = '/home';
                            // },2000);
                        }).catch((err)=>{
                            console.log(err);
                            this.setState({message: 'Error: Service Down'});
                        });
                }
                break;
            case 'mydelete':
                this.setState({isDelete: !this.state.isDelete});
                break;  
            default:
                break;
        }
        if(errmsg) this.setState({message: msg});
        if(mutedmsg) this.setState({notemessage: msg1});
    }

    onChangeEvent = (e) => {
        let name = e.target.name;
        let val = e.target.value;
        this.setState({[name]: val});
    }

    renderElement(prop){
        switch(prop.type){
            case "input":
                return(
                    <input id={prop.id} name={prop.id} placeholder={prop.placeholder} maxLength={prop.length} />
                );
            case "button":
                return(
                    <button id={prop.id} className={prop.cs} onClick={() => this.onButtonEvent(prop.id)}>{prop.value}</button>
                );
            case "textarea":
                return(
                    <textarea id={prop.id} row="8" col="100" maxLength='144' name={prop.id} placeholder={prop.placeholder} onChange={this.onChangeEvent} />
                );
            case 'text':
                return(
                    <h5 className="card-title">{prop.value}</h5>
                );
            case 'para':
                return(
                    <p id={prop.id} className={prop.cs}>{this.state.myreplyerror}</p>
                );
            default:
                break;
        }
    }
    
    render() {
        let items = this.control.response.leftitems;

        return (
            <div id="tweetpage">
                <div id='main' className="card mb-3">
                    <div className="row no-gutters pro-box">
                        <div id="leftcontainer" >
                            <a href="/home">Back</a>
                            <h5 className="card-title">{items.title}</h5>
                            {items.tweet?
                                <div className="card-text">
                                    <div id="tweetmessage">TWEET: {this.props.data.tweetMessage}</div>
                                    <div id="ID">{items.posted}{this.props.data.loginId}</div>
                                    <div id="likes">{items.likes}{this.props.data.likeCount}</div>
                                    <div id="tweettime">{items.time}{this.props.data.tweetTime}</div>
                                </div>
                            : null}
                        </div>
                        <div className="col-md-8" id="rightcontainer">
                            {this.state.isDelete ? 
                                this.state.showOptions ?
                                    (<div className="card-body"> 
                                        <div className="card-text">
                                        {/* <h5 className="card-title">{items.subtitle}</h5> */}
                                            {this.control.response.rightitems.props.map((prop) =>
                                            <div className="row">
                                                <div className="col-md-8 options">
                                                { this.renderElement(prop) }
                                                </div>
                                            </div>)}
                                        </div>
                                        <p className="card-text"><small className="error">{this.state.message}</small></p>
                                        <p className="card-text"><small className="text-muted">{this.state.notemessage}</small></p>
                                        <hr />
                                        {!this.state.postOption ? null : <div><button id='optionsbtn' className='btn btn-primary' onClick={() => this.setState({showOptions: !this.state.showOptions})}>Back</button><br /><br /></div>}
                                    </div>)
                                    :
                                    (<div className="card-body"> 
                                        <div className="card-text">
                                        <h5 className="card-title">REPLIES</h5>
                                            {this.state.displayreplies ?
                                                <div>
                                                    <div className="replybox">
                                                        {this.state.displayreplies.map((prop) =>
                                                        <div className="row">
                                                            <div className="col-md-8 options">
                                                                <strong>{prop.loginId}: </strong>{prop.replyMessage}
                                                            </div>
                                                        </div>)}
                                                    </div>
                                                    <button id='optionsbtn' className='btn btn-primary' onClick={() => this.setState({showOptions: !this.state.showOptions})}>Options</button>
                                                </div>
                                            :
                                                <div>
                                                    <div className="row col-md-8 options">
                                                        <p className="card-text"><small className="text-muted">No comments yet!</small></p>
                                                    </div>
                                                    <button id='optionsbtn' className='btn btn-primary' onClick={() => this.setState({showOptions: !this.state.showOptions})}>Options</button>
                                                </div>
                                            }
                                        </div>
                                    </div>)
                            :
                            (<div className="card-body"> 
                                <div className="card-text row">
                                <h5 className="card-title" id='overlaydelete'>Do you want to delete this post?</h5>
                                    <button id='OKdelete' className='btn btn-outline-danger' onClick={() => this.deleterelated(true)}>OK, Delete</button>
                                    <button id='canceldelete' className='btn btn-outline-secondary' onClick={() => this.deleterelated(false)}>NO, Cancel</button>
                                </div>
                                <p className="card-text"><small className="text-muted">{this.state.notemessage}</small></p>
                            </div>)}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Tweet;
