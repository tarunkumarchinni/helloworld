
import axios from 'axios';
var CryptoJS = require("crypto-js"); 
const url = 'http://3.219.28.126:8087/tweets';
let data;

const TweetService = {
    encrypt(data){
        return CryptoJS.AES.encrypt(data, 'my-secret-key@123').toString();
    },
    decrypt(data){
        var bytes = CryptoJS.AES.decrypt(data, 'my-secret-key@123');
        return bytes.toString(CryptoJS.enc.Utf8);
    },
    getService(URL, rtype, body){
        console.log(body);
        if(body){
            axios.get(`${url}${URL}`, body)
            .then((res)=>{
                    data = res.data;
                }).catch((err)=>{
                    console.log(err);
                    data = rtype;
                });
        } else {
            axios.get(`${url}${URL}`)
            .then((res)=>{
                data = res.data;
            }).catch((err)=>{
                console.log(err);
                data = rtype;
            });
        }
        return data;
    },
    postService(URL, rtype, body){
        axios.post(`${url}${URL}`, body)
        // {
        //     "loginId": "add",
        //     "firstName":"A",
        //     "lastName": "lobs",
        //     "contactNumber": "1111",
        //     "dob": "2000/01/12",
        //     "email": "cream@gmail.com",
        //     "password": "Vital"
        // }
        .then((res)=>{
                data = res.data;
            }).catch((err)=>{
                console.log(err);
                data = rtype;
            });
        return data;
    },
    putService(URL, rtype){
        axios.put(`${url}${URL}`)
        .then((res)=>{
                data = res.data;
            }).catch((err)=>{
                console.log(err);
                data = rtype;
            });
        return data;
    },
    deleteService(URL, rtype){
        axios.delete(`${url}${URL}`)
        .then((res)=>{
                data = res.data;
            }).catch((err)=>{
                console.log(err);
                data = rtype;
            });
        return data;
    }
}

export default TweetService