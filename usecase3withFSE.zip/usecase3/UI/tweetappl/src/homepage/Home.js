import axios from 'axios';
import React, { Component } from 'react'
import './Home.scss'

class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pagedata: '',
            pageerror: '',
            showsearchbar: false,
            showresetcard: false,
            searcherror: '',
            reseterror: '',
            srname: '',
            rtoldpwd: '',
            rtpwd: '',
            rtcpwd: ''
        }
        this.details=[
            {
                key:"First name",
                value:"firstName"
            },
            {
                key:"Last name",
                value:"lastName"
            },
            {
                key:"Login ID",
                value:"loginId"
            },
            {
                key:"Date of birth",
                value:"dob"
            },
            {
                key:"Email ID",
                value:"email"
            },
            {
                key:"Contact Number",
                value:"contactNumber"
            }
        ]
        axios.get(`http://localhost:8081/tweets/user/search/${this.props.name}`)
            .then((res)=>{
                if(res.data) this.setState({pagedata: res.data});
            }).catch((err)=>{
                console.log(err);
                this.setState({pageerror: 'Error: Service Down'});
            });
    }

    check(value, type){
        let pattern;
        switch(type){
            case 'id':
                pattern = /^[A-Za-z]{6,13}$/;
                break;
            case 'pwd':
                pattern = /^[a-zA-Z0-9]{2,8}/;
                break;
            default: 
                break;
        }
        return !pattern.test(value);
    }

    onChangeEvent = (e) => {
        let name = e.target.name;
        let val = e.target.value;
        this.setState({[name]: val});
    }

    showsearchbar(status = !this.state.showsearchbar){
        this.setState({showsearchbar: status});
        if(status){
            if(document.getElementsByClassName("active")) this.showresetcard(false);
            document.getElementById("searchcard").classList.add("active")
        } else if(document.getElementById("searchcard")) {
            document.getElementById("searchcard").classList.remove("active");
            this.setState({searcherror: ''});
        }
    }

    showresetcard(status = !this.state.showresetcard){
        this.setState({showresetcard: status});
        if(status){
            if(document.getElementsByClassName("active")) this.showsearchbar(false);
            document.getElementById("showresetcard").classList.add("active")
        } else if(document.getElementById("showresetcard")) {
            document.getElementById("showresetcard").classList.remove("active");
        }
    }
    
    validate(type){
        if(type === 'search'){
            if(this.check(this.state.srname, 'id')){
                this.setState({searcherror: 'Enter valid username'});
            } else {
                axios.get(`http://localhost:8081/tweets/user/search/${this.state.srname}`)
                    .then((res)=>{
                        if(res.data) this.props.searchname(this.state.srname, 'NAME');
                        else this.setState({searcherror: 'No such user found!'});
                    }).catch((err)=>{
                        console.log(err);
                        this.setState({searcherror: 'Error: Service Down'});
                    });
            }
        } else if(type === 'reset'){
            let error = '';
            if(this.state.rtpwd !== this.state.rtcpwd) error = 'Enter same passwords in fields';
            else if(!error && (this.check(this.state.rtpwd, 'pwd') || this.check(this.state.rtcpwd, 'pwd') || this.check(this.state.rtoldpwd, 'pwd'))) error = 'Enter valid password(s)';
            else{
                axios.put(`http://localhost:8081/tweets/${this.props.name}/${this.state.rtpwd}/${this.state.rtoldpwd}/resetPassword`)
                    .then((res)=>{
                        console.log()
                        if(res.data){
                            error =  'Password resetted successfully!';
                            setTimeout(() => {
                                this.showresetcard(false);
                                this.setState({reseterror: ''});
                            }, 2000);
                        } else error = 'Incorrect Password';
                        this.setState({reseterror: error});
                    }).catch((err)=>{
                        console.log(err);
                        this.setState({reseterror: 'Error: Service Down'});
                    });
            }
            this.setState({reseterror: error});
        } else if(type === 'all') this.props.searchname('All', 'ALL');
        else if(type === 'mytweets') this.props.searchname(this.props.name, 'NAME');
    }

    passprops(){
        this.props.clearData();
    }

    render() {
        if(this.state.pagedata){
            return (
                <div id="home">
                    <div className="card mb-3" >
                        <div className="row no-gutters pro-box">
                            <div id="leftcontainer">
                                <h5 className="card-title">Profile Details</h5><h6><a tabIndex="0" onClick={() => this.passprops()}>Log out</a></h6>
                                
                                <div className="card-text wrapper">
                                    {this.details.map(prop => 
                                        <div className="keyvalue-pair box">
                                            <span className="key">{prop.key}  </span>
                                            <span className="value">{this.state.pagedata[prop.value]}</span>
                                        </div>
                                    )}

                                </div>

                            </div>
                            <div className="col-md-8" id="rightcontainer">
                                <div className="card-body">
                                    
                                    <div className="card-text">
                                    <h5 className="card-title">Personal Options</h5>
                                        <div className="row">
                                            <div className="card col-md-3 options" tabIndex="0" onClick={() => window.location.href="/posttweet"}>
                                                Post tweet
                                            </div>
                                            <div className="card offset-md-1 col-md-3 options" tabIndex="0" onClick={() => this.validate('mytweets')}>
                                                View/Edit tweet
                                            </div>
                                            <div className="card offset-md-1 col-md-3 options" id="showresetcard" tabIndex="0" onClick={() => this.showresetcard()}>
                                                Reset password
                                            </div>
                                            
                                        </div>
                                    <h5 className="card-title">Other Options</h5>
                                        <div className="row">
                                            <div className="card col-md-5 options" tabIndex="0" onClick={() => this.validate('all')}>
                                                Get All Tweets
                                            </div>
                                            <div className="card offset-md-2 col-md-5 options" id="searchcard" tabIndex="0" onClick={() => this.showsearchbar()}>
                                                Search by username
                                            </div>
                                        </div>
                                        {this.state.showsearchbar ?
                                        <div className="card searchcard">
                                            <h5 className="card-title">Search by username to view their tweets</h5>
                                            <div className="row">
                                                <input placeholder="Username" type="text" id="username" name='srname' maxLength="12" onChange={this.onChangeEvent} />
                                            </div>
                                            <div className="row">
                                                <button id="usersearch" className="btn btn-outline-primary" onClick={() => this.validate('search')}>SEARCH</button>
                                            </div>
                                            <p className="card-text"><small className="error">{this.state.searcherror}</small></p>
                                        </div>
                                        : null}
                                        {this.state.showresetcard ?
                                        <div className="card resetcard">
                                            <h5 className="card-title">Reset Password</h5>
                                            <div className="row">
                                            <input placeholder="Enter old password" type="password" id="password" name='rtoldpwd' onChange={this.onChangeEvent} />
                                                <input placeholder="Enter new password" type="password" id="password" name='rtpwd' onChange={this.onChangeEvent} />
                                                <input placeholder="Re enter password" type="password" id="rpassword" name='rtcpwd' onChange={this.onChangeEvent} />
                                            </div>
                                            <div className="row">
                                                <button id="userreset" className="btn btn-outline-primary" onClick={() => this.validate('reset')}>RESET</button>
                                            </div>
                                            <p className="card-text"><small className="error">{this.state.reseterror}</small></p>
                                        </div>
                                        : null}
                                    </div>
                                    {/* <p className="card-text"><small className="text-muted">Last updated 3 mins ago</small></p> */}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            );
        } else if(this.state.pageerror){
            return (
                <div id="home" className="pageerror">
                    <div className="card mb-3" >
                        <div className="row no-gutters">
                            <div id="leftcontainer" className="">
                                <h5 className="card-title">OOPS!<br/> Something went wrong!</h5>
                                <a tabIndex="0" onClick={() => this.passprops()}>Logout</a>
                            </div>
                            <div className="col-md-8" id="rightcontainer">
                                <div className="card-body">
                                    <div className="card-text">
                                    <h5 className="card-title">{this.state.pageerror}</h5>
                                    </div>
                                    <p className="card-text"><small className="text-muted">Please try again later</small></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            );
        } return null;
    }
}

export default Home;
