package com.tweetapp.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tweetapp.model.User;

public interface UserRepository extends MongoRepository<User, String>{
	public User findByloginId(String loginId);
//	public List<User> findByLastName(String lastName);

}
