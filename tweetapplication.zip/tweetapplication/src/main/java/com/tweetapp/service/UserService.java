package com.tweetapp.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.PatternSyntaxException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.validation.annotation.Validated;

import com.tweetapp.model.User;
import com.tweetapp.repository.UserRepository;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
@CrossOrigin(origins = "http://localhost:8080")
@RestController
public class UserService {

	@Autowired
	private UserRepository repository;
	
	@RequestMapping(value = "/api/v1.0/tweets/register", method = RequestMethod.POST)
	public User addNewUser(@RequestBody User user) {
		return repository.save(user); //completed
	}
	
	@RequestMapping(value = "/api/v1.0/tweets/login", method = RequestMethod.GET)
	public List<User> Login() {
		List<User> usersList=new ArrayList<User>();
		usersList.addAll(repository.findAll());
		return usersList;//not clear
	}
	
	@RequestMapping(value = "/api/v1.0/tweets/{username}/forgot", method = RequestMethod.GET)
	public User forgetPassword(@PathVariable String username) {
		List<User> users=new ArrayList<User>();
		repository.findAll().forEach(users::add);
		return users.stream().filter(t->t.getLoginId().equals(username)).findFirst().get(); //completed
	}
	
	@RequestMapping(value = "/api/v1.0/tweets/users/all", method = RequestMethod.GET)
	public List<User> getAllUsers() {
		List<User> usersList=new ArrayList<User>();
		usersList.addAll(repository.findAll());
		return usersList;//completed
	}
	
	@Autowired
	private MongoTemplate mongoOperations;
	@RequestMapping(value = "/api/v/1.0/tweets/user/search/{username}", method = RequestMethod.GET)
	public List<User> getUserById(@PathVariable String username) {
	        try{
	            Query query = new Query();
	            Criteria criteria = new Criteria();
	            criteria.orOperator(Criteria.where("firstName").regex(toLikeRegex(username)),Criteria.where("lastName").regex(toLikeRegex(username)));
	            query.addCriteria(criteria);
	            return mongoOperations.find(query, User.class);
	        } catch(PatternSyntaxException e) {
	            return Collections.emptyList();
	        } 
	}//complete
	
	 private String toLikeRegex(String source) {
	        return source.replaceAll("\\*", ".*");
	    }
	
	
}
