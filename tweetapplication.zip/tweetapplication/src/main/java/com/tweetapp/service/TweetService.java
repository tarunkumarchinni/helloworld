package com.tweetapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import com.tweetapp.model.Tweet;
import com.tweetapp.model.User;
import com.tweetapp.repository.TweetRepository;

@CrossOrigin(origins = "http://localhost:8080")
@RestController
public class TweetService {
	@Autowired
	private TweetRepository repository;

	@RequestMapping(value = "/api/v1.0/tweets/all", method = RequestMethod.GET)
	public List<Tweet> getAllTweets() {
		List<Tweet> tweetList=new ArrayList<Tweet>();
		tweetList.addAll(repository.findAll());
		return tweetList;//completed
	}
	
	@RequestMapping(value = "/api/v1.0/tweets/{username}", method = RequestMethod.GET)
	public Stream<Tweet> getTweetsByUser(@PathVariable String username) {
		List<Tweet> tweetList=new ArrayList<Tweet>();
		repository.findAll().forEach(tweetList::add);
		return tweetList.stream().filter(t->t.getLoginId().equals(username));
	}//completed
	
	@RequestMapping(value = "/api/v1.0/tweets/{username}/add", method = RequestMethod.POST)
	public Tweet addNewTweet(@RequestBody Tweet tweet) {
		return repository.save(tweet);
	}//completed

	@Autowired
	private MongoTemplate mongoTemplate;
	@RequestMapping(value = "/api/v1.0/tweets/{username}/update/{id}", method = RequestMethod.PUT)
	public UpdateResult updateUserTweet(@RequestBody Tweet tweet,@PathVariable String username,@PathVariable String id) {
		Query query = new Query();
		Criteria criteria = new Criteria();
        criteria.andOperator(Criteria.where("id").is(id),Criteria.where("loginId").is(username));
        query.addCriteria(criteria);
        Update updateTweet = new Update();
        
        updateTweet.set("loginId", tweet.getLoginId());
        updateTweet.set("tweet", tweet.getTweet());
        updateTweet.set("timestamp", tweet.getTimestamp());
		return mongoTemplate.updateFirst(query, updateTweet, Tweet.class);
	}//complete

	@RequestMapping(value = "/api/v1.0/tweets/{username}/delete/{id}", method = RequestMethod.DELETE)
	public DeleteResult deleteUserTweet(@PathVariable String username,@PathVariable String id) {
		Query query = new Query();
		Criteria criteria = new Criteria();
        criteria.andOperator(Criteria.where("id").is(id),Criteria.where("loginId").is(username));
        query.addCriteria(criteria);
//        Query query = new Query(Criteria.where("id").is(id));
        
		return mongoTemplate.remove(query, Tweet.class, "Tweets");
	}//completed

	@RequestMapping(value = "/api/v1.0/tweets/{username}/like/{id}", method = RequestMethod.PUT)
	public UpdateResult likeTweet(@PathVariable String username,@PathVariable String id) {
		//getting the like number
		List<Tweet> tweetList=new ArrayList<Tweet>();
		Tweet tweetData=new Tweet();
		repository.findAll().forEach(tweetList::add);
		tweetData=tweetList.stream().filter(t->t.getId().equals(id)).findFirst().get();
		//like update
		Query query = new Query();
		Criteria criteria = new Criteria();
        criteria.andOperator(Criteria.where("id").is(id),Criteria.where("loginId").is(username));
        query.addCriteria(criteria);
        Update updateTweet = new Update();
        updateTweet.set("like", tweetData.getLike()+1);
		return mongoTemplate.updateFirst(query, updateTweet, Tweet.class);
	}

	@RequestMapping(value = "/api/v1.0/tweets/{username}/reply/{id}", method = RequestMethod.POST)
	public void replyToTweet(@RequestBody Tweet tweet,@PathVariable String username,@PathVariable String id) {
		//saving the reply comment
		repository.save(tweet);
		//getting the inserted tweet
		List<Tweet> tweetList=new ArrayList<Tweet>();
		Tweet tweetData=new Tweet();
		repository.findAll().forEach(tweetList::add);
		for(int i=0;i<tweetList.size();i++){
			Tweet p=tweetList.get(i);
			if(p.getLoginId().equals(tweet.getLoginId()) && p.getTweet().equals(tweet.getTweet())){
				tweetData=p;
			}
		}
		//tweetData=tweetList.stream().filter(t->t.getLoginId().equals(tweet.getLoginId())).map(t->t.getTweet().equals(tweet.getTweet())).findFirst().get();
		
		//updateing the inserted data tweet
	
		Query query = new Query();
		Criteria criteria = new Criteria();
        criteria.andOperator(Criteria.where("id").is(id),Criteria.where("loginId").is(username));
        query.addCriteria(criteria);
        Update updateTweet = new Update();
        
//        Tweet response=new Tweet(tweetData.getId(),tweetData.getLoginId(),tweetData.getTweet(),tweetData.getTimestamp())
        
        updateTweet.set("like", tweetData.getLike()+1);
        updateTweet.set("reply",tweetData);
		mongoTemplate.updateFirst(query, updateTweet, Tweet.class);
		
	}

}
