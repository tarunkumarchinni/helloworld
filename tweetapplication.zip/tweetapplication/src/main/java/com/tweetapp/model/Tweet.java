package com.tweetapp.model;

import java.util.ArrayList;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "Tweets")
public class Tweet {
	public Tweet(String id, String loginId, String tweet, String timestamp) {
		super();
		this.id = id;
		this.loginId = loginId;
		this.tweet = tweet;
		this.timestamp = timestamp;
	}
	public Tweet(String id, String loginId, String tweet, String timestamp, int like) {
		super();
		this.id = id;
		this.loginId = loginId;
		this.tweet = tweet;
		this.timestamp = timestamp;
		this.like = like;
	}
	@Id
	private String id;
	private String loginId;
	private String tweet;
	private String timestamp;
	private int like=0;
	private ArrayList reply;
	public Tweet(String id, String loginId, String tweet, String timestamp, int like, ArrayList reply) {
		super();
		this.id = id;
		this.loginId = loginId;
		this.tweet = tweet;
		this.timestamp = timestamp;
		this.like = like;
		this.reply = reply;
	}
	public Tweet() {
		// TODO Auto-generated constructor stub
	}
	public int getLike() {
		return like;
	}
	public void setLike(int like) {
		this.like = like;
	}
	public ArrayList getReply() {
		return reply;
	}
	public void setReply(ArrayList reply) {
		this.reply = reply;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getTweet() {
		return tweet;
	}
	public void setTweet(String tweet) {
		this.tweet = tweet;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

}
